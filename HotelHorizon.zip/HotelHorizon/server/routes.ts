import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import jwt from "jsonwebtoken";
import { insertRoomSchema, insertGuestSchema, insertBookingSchema } from "@shared/schema";
import { z } from "zod";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify JWT token
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password required" });
      }

      const user = await storage.validateUser(email, password);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Public routes - Room search and booking
  app.get("/api/rooms", async (req, res) => {
    try {
      const { type, capacity, checkIn, checkOut } = req.query;
      
      const filters: any = {};
      if (type) filters.type = type;
      if (capacity) filters.capacity = parseInt(capacity as string);
      if (checkIn) filters.checkIn = new Date(checkIn as string);
      if (checkOut) filters.checkOut = new Date(checkOut as string);

      const rooms = await storage.searchRooms(filters);
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rooms" });
    }
  });

  app.get("/api/rooms/:id", async (req, res) => {
    try {
      const room = await storage.getRoomById(req.params.id);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }
      res.json(room);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch room" });
    }
  });

  // Create booking (public)
  app.post("/api/bookings", async (req, res) => {
    try {
      // First, create or find guest
      const guestData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phone: req.body.phone,
      };

      let guest = await storage.getGuestByEmail(guestData.email);
      if (!guest) {
        const validatedGuest = insertGuestSchema.parse(guestData);
        guest = await storage.createGuest(validatedGuest);
      }

      // Calculate nights and total
      const checkIn = new Date(req.body.checkInDate);
      const checkOut = new Date(req.body.checkOutDate);
      const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));

      // Get room price
      const room = await storage.getRoomById(req.body.roomId);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }

      const totalAmount = Number(room.price) * nights;

      const bookingData = {
        guestId: guest.id,
        roomId: req.body.roomId,
        checkInDate: checkIn,
        checkOutDate: checkOut,
        nights,
        totalAmount: totalAmount.toString(),
        specialRequests: req.body.specialRequests || null,
        status: 'confirmed' as const,
      };

      const validatedBooking = insertBookingSchema.parse(bookingData);
      const booking = await storage.createBooking(validatedBooking);

      // Update room status to occupied
      await storage.updateRoomStatus(req.body.roomId, 'occupied');

      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // Protected admin routes
  app.get("/api/admin/rooms", authenticateToken, async (req, res) => {
    try {
      const rooms = await storage.getAllRooms();
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rooms" });
    }
  });

  app.post("/api/admin/rooms", authenticateToken, async (req, res) => {
    try {
      const validatedRoom = insertRoomSchema.parse(req.body);
      const room = await storage.createRoom(validatedRoom);
      res.status(201).json(room);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid room data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create room" });
    }
  });

  app.put("/api/admin/rooms/:id", authenticateToken, async (req, res) => {
    try {
      const room = await storage.updateRoom(req.params.id, req.body);
      res.json(room);
    } catch (error) {
      res.status(500).json({ message: "Failed to update room" });
    }
  });

  app.delete("/api/admin/rooms/:id", authenticateToken, async (req, res) => {
    try {
      await storage.deleteRoom(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete room" });
    }
  });

  app.patch("/api/admin/rooms/:id/status", authenticateToken, async (req, res) => {
    try {
      const { status } = req.body;
      const room = await storage.updateRoomStatus(req.params.id, status);
      res.json(room);
    } catch (error) {
      res.status(500).json({ message: "Failed to update room status" });
    }
  });

  // Booking management
  app.get("/api/admin/bookings", authenticateToken, async (req, res) => {
    try {
      const bookings = await storage.getAllBookings();
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.get("/api/admin/bookings/:id", authenticateToken, async (req, res) => {
    try {
      const booking = await storage.getBookingById(req.params.id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch booking" });
    }
  });

  app.put("/api/admin/bookings/:id", authenticateToken, async (req, res) => {
    try {
      const booking = await storage.updateBooking(req.params.id, req.body);
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to update booking" });
    }
  });

  app.patch("/api/admin/bookings/:id/cancel", authenticateToken, async (req, res) => {
    try {
      const booking = await storage.cancelBooking(req.params.id);
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to cancel booking" });
    }
  });

  // Guest management
  app.get("/api/admin/guests", authenticateToken, async (req, res) => {
    try {
      const guests = await storage.getAllGuests();
      res.json(guests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch guests" });
    }
  });

  app.get("/api/admin/guests/:id", authenticateToken, async (req, res) => {
    try {
      const guest = await storage.getGuestById(req.params.id);
      if (!guest) {
        return res.status(404).json({ message: "Guest not found" });
      }
      res.json(guest);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch guest" });
    }
  });

  app.put("/api/admin/guests/:id", authenticateToken, async (req, res) => {
    try {
      const guest = await storage.updateGuest(req.params.id, req.body);
      res.json(guest);
    } catch (error) {
      res.status(500).json({ message: "Failed to update guest" });
    }
  });

  // Analytics and reports
  app.get("/api/admin/analytics/occupancy", authenticateToken, async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      const start = startDate ? new Date(startDate as string) : undefined;
      const end = endDate ? new Date(endDate as string) : undefined;
      
      const occupancyRate = await storage.getOccupancyRate(start, end);
      res.json({ occupancyRate });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch occupancy data" });
    }
  });

  app.get("/api/admin/analytics/revenue", authenticateToken, async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      const start = startDate ? new Date(startDate as string) : undefined;
      const end = endDate ? new Date(endDate as string) : undefined;
      
      const revenue = await storage.getRevenue(start, end);
      res.json({ revenue });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch revenue data" });
    }
  });

  app.get("/api/admin/analytics/booking-stats", authenticateToken, async (req, res) => {
    try {
      const stats = await storage.getBookingStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch booking statistics" });
    }
  });

  app.get("/api/admin/analytics/room-types", authenticateToken, async (req, res) => {
    try {
      const stats = await storage.getRoomTypeStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch room type statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
