import { users, rooms, guests, bookings, type User, type InsertUser, type Room, type InsertRoom, type Guest, type InsertGuest, type Booking, type InsertBooking, type BookingWithDetails } from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, sql, count, sum } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // User management
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  validateUser(email: string, password: string): Promise<User | null>;

  // Room management
  getAllRooms(): Promise<Room[]>;
  getRoomById(id: string): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: string, room: Partial<InsertRoom>): Promise<Room>;
  deleteRoom(id: string): Promise<void>;
  searchRooms(filters: { type?: string; capacity?: number; checkIn?: Date; checkOut?: Date }): Promise<Room[]>;
  updateRoomStatus(id: string, status: string): Promise<Room>;

  // Guest management
  getAllGuests(): Promise<Guest[]>;
  getGuestById(id: string): Promise<Guest | undefined>;
  getGuestByEmail(email: string): Promise<Guest | undefined>;
  createGuest(guest: InsertGuest): Promise<Guest>;
  updateGuest(id: string, guest: Partial<InsertGuest>): Promise<Guest>;

  // Booking management
  getAllBookings(): Promise<BookingWithDetails[]>;
  getBookingById(id: string): Promise<BookingWithDetails | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: string, booking: Partial<InsertBooking>): Promise<Booking>;
  cancelBooking(id: string): Promise<Booking>;
  getBookingsByDateRange(startDate: Date, endDate: Date): Promise<BookingWithDetails[]>;

  // Analytics
  getOccupancyRate(startDate?: Date, endDate?: Date): Promise<number>;
  getRevenue(startDate?: Date, endDate?: Date): Promise<number>;
  getBookingStats(): Promise<{ total: number; pending: number; confirmed: number; checkedIn: number; checkedOut: number; cancelled: number }>;
  getRoomTypeStats(): Promise<{ type: string; count: number; occupancyRate: number }[]>;
}

export class DatabaseStorage implements IStorage {
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, password: hashedPassword })
      .returning();
    return user;
  }

  async validateUser(email: string, password: string): Promise<User | null> {
    const user = await this.getUserByEmail(email);
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async getAllRooms(): Promise<Room[]> {
    return await db.select().from(rooms).orderBy(rooms.number);
  }

  async getRoomById(id: string): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room || undefined;
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const [room] = await db
      .insert(rooms)
      .values(insertRoom)
      .returning();
    return room;
  }

  async updateRoom(id: string, updateData: Partial<InsertRoom>): Promise<Room> {
    const [room] = await db
      .update(rooms)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(rooms.id, id))
      .returning();
    return room;
  }

  async deleteRoom(id: string): Promise<void> {
    await db.delete(rooms).where(eq(rooms.id, id));
  }

  async searchRooms(filters: { type?: string; capacity?: number; checkIn?: Date; checkOut?: Date }): Promise<Room[]> {
    let query = db.select().from(rooms);
    
    const conditions = [eq(rooms.status, 'available')];
    
    if (filters.type) {
      conditions.push(eq(rooms.type, filters.type as any));
    }
    
    if (filters.capacity) {
      conditions.push(gte(rooms.capacity, filters.capacity));
    }
    
    // Check room availability for date range
    if (filters.checkIn && filters.checkOut) {
      const conflictingBookings = await db
        .select({ roomId: bookings.roomId })
        .from(bookings)
        .where(
          and(
            lte(bookings.checkInDate, filters.checkOut),
            gte(bookings.checkOutDate, filters.checkIn),
            sql`${bookings.status} NOT IN ('cancelled', 'checked_out')`
          )
        );
      
      const unavailableRoomIds = conflictingBookings.map(b => b.roomId);
      if (unavailableRoomIds.length > 0) {
        conditions.push(sql`${rooms.id} NOT IN (${unavailableRoomIds.map(() => '?').join(', ')})`, ...unavailableRoomIds);
      }
    }
    
    return await query.where(and(...conditions)).orderBy(rooms.price);
  }

  async updateRoomStatus(id: string, status: string): Promise<Room> {
    const [room] = await db
      .update(rooms)
      .set({ status: status as any, updatedAt: new Date() })
      .where(eq(rooms.id, id))
      .returning();
    return room;
  }

  async getAllGuests(): Promise<Guest[]> {
    return await db.select().from(guests).orderBy(desc(guests.createdAt));
  }

  async getGuestById(id: string): Promise<Guest | undefined> {
    const [guest] = await db.select().from(guests).where(eq(guests.id, id));
    return guest || undefined;
  }

  async getGuestByEmail(email: string): Promise<Guest | undefined> {
    const [guest] = await db.select().from(guests).where(eq(guests.email, email));
    return guest || undefined;
  }

  async createGuest(insertGuest: InsertGuest): Promise<Guest> {
    const [guest] = await db
      .insert(guests)
      .values(insertGuest)
      .returning();
    return guest;
  }

  async updateGuest(id: string, updateData: Partial<InsertGuest>): Promise<Guest> {
    const [guest] = await db
      .update(guests)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(guests.id, id))
      .returning();
    return guest;
  }

  async getAllBookings(): Promise<BookingWithDetails[]> {
    return await db
      .select()
      .from(bookings)
      .leftJoin(guests, eq(bookings.guestId, guests.id))
      .leftJoin(rooms, eq(bookings.roomId, rooms.id))
      .orderBy(desc(bookings.createdAt))
      .then(results => 
        results.map(result => ({
          ...result.bookings,
          guest: result.guests!,
          room: result.rooms!
        }))
      );
  }

  async getBookingById(id: string): Promise<BookingWithDetails | undefined> {
    const [result] = await db
      .select()
      .from(bookings)
      .leftJoin(guests, eq(bookings.guestId, guests.id))
      .leftJoin(rooms, eq(bookings.roomId, rooms.id))
      .where(eq(bookings.id, id));
    
    if (!result) return undefined;
    
    return {
      ...result.bookings,
      guest: result.guests!,
      room: result.rooms!
    };
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    // Generate booking number
    const bookingNumber = `BK${new Date().getFullYear()}${String(Date.now()).slice(-6)}`;
    
    const [booking] = await db
      .insert(bookings)
      .values({ ...insertBooking, bookingNumber })
      .returning();
    
    // Update guest stats
    await db
      .update(guests)
      .set({
        totalBookings: sql`${guests.totalBookings} + 1`,
        totalSpent: sql`${guests.totalSpent} + ${insertBooking.totalAmount}`,
        lastVisit: new Date(),
        updatedAt: new Date()
      })
      .where(eq(guests.id, insertBooking.guestId));
    
    return booking;
  }

  async updateBooking(id: string, updateData: Partial<InsertBooking>): Promise<Booking> {
    const [booking] = await db
      .update(bookings)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(bookings.id, id))
      .returning();
    return booking;
  }

  async cancelBooking(id: string): Promise<Booking> {
    const [booking] = await db
      .update(bookings)
      .set({ status: 'cancelled', updatedAt: new Date() })
      .where(eq(bookings.id, id))
      .returning();
    return booking;
  }

  async getBookingsByDateRange(startDate: Date, endDate: Date): Promise<BookingWithDetails[]> {
    return await db
      .select()
      .from(bookings)
      .leftJoin(guests, eq(bookings.guestId, guests.id))
      .leftJoin(rooms, eq(bookings.roomId, rooms.id))
      .where(
        and(
          gte(bookings.checkInDate, startDate),
          lte(bookings.checkOutDate, endDate)
        )
      )
      .orderBy(bookings.checkInDate)
      .then(results => 
        results.map(result => ({
          ...result.bookings,
          guest: result.guests!,
          room: result.rooms!
        }))
      );
  }

  async getOccupancyRate(startDate?: Date, endDate?: Date): Promise<number> {
    const totalRoomsResult = await db.select({ count: count() }).from(rooms);
    const totalRooms = totalRoomsResult[0].count;
    
    if (!startDate || !endDate) {
      const occupiedRoomsResult = await db
        .select({ count: count() })
        .from(rooms)
        .where(eq(rooms.status, 'occupied'));
      const occupiedRooms = occupiedRoomsResult[0].count;
      return (occupiedRooms / totalRooms) * 100;
    }
    
    // Calculate occupancy for date range
    const occupiedBookingsResult = await db
      .select({ count: count() })
      .from(bookings)
      .where(
        and(
          lte(bookings.checkInDate, endDate),
          gte(bookings.checkOutDate, startDate),
          sql`${bookings.status} IN ('confirmed', 'checked_in')`
        )
      );
    
    const occupiedBookings = occupiedBookingsResult[0].count;
    return (occupiedBookings / totalRooms) * 100;
  }

  async getRevenue(startDate?: Date, endDate?: Date): Promise<number> {
    let query = db.select({ total: sum(bookings.totalAmount) }).from(bookings);
    
    if (startDate && endDate) {
      query = query.where(
        and(
          gte(bookings.createdAt, startDate),
          lte(bookings.createdAt, endDate),
          sql`${bookings.status} NOT IN ('cancelled')`
        )
      );
    } else {
      query = query.where(sql`${bookings.status} NOT IN ('cancelled')`);
    }
    
    const result = await query;
    return Number(result[0].total) || 0;
  }

  async getBookingStats(): Promise<{ total: number; pending: number; confirmed: number; checkedIn: number; checkedOut: number; cancelled: number }> {
    const stats = await db
      .select({
        status: bookings.status,
        count: count()
      })
      .from(bookings)
      .groupBy(bookings.status);
    
    const result = {
      total: 0,
      pending: 0,
      confirmed: 0,
      checkedIn: 0,
      checkedOut: 0,
      cancelled: 0
    };
    
    stats.forEach(stat => {
      result.total += stat.count;
      switch (stat.status) {
        case 'pending': result.pending = stat.count; break;
        case 'confirmed': result.confirmed = stat.count; break;
        case 'checked_in': result.checkedIn = stat.count; break;
        case 'checked_out': result.checkedOut = stat.count; break;
        case 'cancelled': result.cancelled = stat.count; break;
      }
    });
    
    return result;
  }

  async getRoomTypeStats(): Promise<{ type: string; count: number; occupancyRate: number }[]> {
    const roomStats = await db
      .select({
        type: rooms.type,
        total: count(),
        occupied: sql<number>`SUM(CASE WHEN ${rooms.status} = 'occupied' THEN 1 ELSE 0 END)`
      })
      .from(rooms)
      .groupBy(rooms.type);
    
    return roomStats.map(stat => ({
      type: stat.type,
      count: stat.total,
      occupancyRate: (Number(stat.occupied) / stat.total) * 100
    }));
  }
}

export const storage = new DatabaseStorage();
