export const translations = {
  en: {
    // Navigation
    home: "Home",
    rooms: "Rooms",
    facilities: "Facilities",
    contact: "Contact",
    bookNow: "Book Now",
    admin: "Admin",
    
    // Hero Section
    heroTitle: "Experience Luxury Like Never Before",
    heroSubtitle: "Discover the epitome of elegance at Azure Palace Hotel, where every moment is crafted to perfection.",
    exploreRooms: "Explore Our Rooms",
    
    // Search Widget
    findRoom: "Find Your Perfect Room",
    checkIn: "Check-in Date",
    checkOut: "Check-out Date",
    roomType: "Room Type",
    guests: "Guests",
    allTypes: "All Types",
    standard: "Standard",
    deluxe: "Deluxe",
    suite: "Suite",
    presidential: "Presidential",
    searchRooms: "Search Rooms",
    
    // Room Types
    standardTwin: "Standard Twin Room",
    deluxeKing: "Deluxe King Room",
    executiveSuite: "Executive Suite",
    presidentialSuite: "Presidential Suite",
    
    // Booking
    selectRoom: "Select Room",
    perNight: "per night",
    completeBooking: "Complete Your Booking",
    bookingSummary: "Booking Summary",
    nights: "Nights",
    totalCost: "Total Cost",
    firstName: "First Name",
    lastName: "Last Name",
    email: "Email Address",
    phone: "Phone Number",
    specialRequests: "Special Requests",
    confirmBooking: "Confirm Booking",
    cancel: "Cancel",
    
    // Admin
    adminLogin: "Admin Login",
    signIn: "Sign In",
    dashboard: "Dashboard",
    roomManagement: "Room Management",
    bookingManagement: "Booking Management",
    reports: "Reports",
    guestManagement: "Guest Management",
    
    // Common
    loading: "Loading...",
    error: "Error",
    success: "Success",
    save: "Save",
    edit: "Edit",
    delete: "Delete",
    view: "View",
    add: "Add",
    update: "Update",
  },
  ar: {
    // Navigation
    home: "الرئيسية",
    rooms: "الغرف",
    facilities: "المرافق",
    contact: "اتصل بنا",
    bookNow: "احجز الآن",
    admin: "الإدارة",
    
    // Hero Section
    heroTitle: "تجربة فاخرة لا مثيل لها",
    heroSubtitle: "اكتشف قمة الأناقة في فندق آزور بالاس، حيث تُصاغ كل لحظة بالكمال.",
    exploreRooms: "استكشف غرفنا",
    
    // Search Widget
    findRoom: "ابحث عن غرفتك المثالية",
    checkIn: "تاريخ الوصول",
    checkOut: "تاريخ المغادرة",
    roomType: "نوع الغرفة",
    guests: "النزلاء",
    allTypes: "جميع الأنواع",
    standard: "عادية",
    deluxe: "ديلوكس",
    suite: "جناح",
    presidential: "جناح رئاسي",
    searchRooms: "البحث عن الغرف",
    
    // Room Types
    standardTwin: "غرفة عادية بسريرين",
    deluxeKing: "غرفة ديلوكس بسرير كبير",
    executiveSuite: "جناح تنفيذي",
    presidentialSuite: "الجناح الرئاسي",
    
    // Booking
    selectRoom: "اختر الغرفة",
    perNight: "لكل ليلة",
    completeBooking: "أكمل حجزك",
    bookingSummary: "ملخص الحجز",
    nights: "ليالي",
    totalCost: "التكلفة الإجمالية",
    firstName: "الاسم الأول",
    lastName: "اسم العائلة",
    email: "البريد الإلكتروني",
    phone: "رقم الهاتف",
    specialRequests: "طلبات خاصة",
    confirmBooking: "تأكيد الحجز",
    cancel: "إلغاء",
    
    // Admin
    adminLogin: "دخول الإدارة",
    signIn: "تسجيل الدخول",
    dashboard: "لوحة التحكم",
    roomManagement: "إدارة الغرف",
    bookingManagement: "إدارة الحجوزات",
    reports: "التقارير",
    guestManagement: "إدارة النزلاء",
    
    // Common
    loading: "جاري التحميل...",
    error: "خطأ",
    success: "نجح",
    save: "حفظ",
    edit: "تعديل",
    delete: "حذف",
    view: "عرض",
    add: "إضافة",
    update: "تحديث",
  }
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.en;
