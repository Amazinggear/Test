import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Room } from "@shared/schema";
import { BookingFormData } from "@/types";

interface BookingModalProps {
  room: Room | null;
  isOpen: boolean;
  onClose: () => void;
  checkIn?: string;
  checkOut?: string;
}

export function BookingModal({ room, isOpen, onClose, checkIn, checkOut }: BookingModalProps) {
  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState<BookingFormData>({
    roomId: room?.id || '',
    checkInDate: checkIn || '',
    checkOutDate: checkOut || '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    specialRequests: '',
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: BookingFormData) => {
      const response = await apiRequest('POST', '/api/bookings', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t('success'),
        description: "Booking confirmed successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/rooms'] });
      onClose();
      setFormData({
        roomId: '',
        checkInDate: '',
        checkOutDate: '',
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        specialRequests: '',
      });
    },
    onError: () => {
      toast({
        title: t('error'),
        description: "Failed to create booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateNights = () => {
    if (!formData.checkInDate || !formData.checkOutDate) return 0;
    const checkIn = new Date(formData.checkInDate);
    const checkOut = new Date(formData.checkOutDate);
    return Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
  };

  const calculateTotal = () => {
    if (!room) return 0;
    return Number(room.price) * calculateNights();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!room) return;

    bookingMutation.mutate({
      ...formData,
      roomId: room.id,
    });
  };

  if (!room) return null;

  const nights = calculateNights();
  const total = calculateTotal();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-screen overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-hotel-text">
            {t('completeBooking')}
          </DialogTitle>
        </DialogHeader>

        <Card className="bg-hotel-bg">
          <CardContent className="p-4">
            <h4 className="font-semibold mb-2">{t('bookingSummary')}</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>{t('roomType')}:</span>
                <span className="font-medium">{room.type}</span>
              </div>
              <div className="flex justify-between">
                <span>{t('checkIn')}:</span>
                <span>{formData.checkInDate}</span>
              </div>
              <div className="flex justify-between">
                <span>{t('checkOut')}:</span>
                <span>{formData.checkOutDate}</span>
              </div>
              <div className="flex justify-between">
                <span>{t('nights')}:</span>
                <span>{nights}</span>
              </div>
              <div className="border-t pt-2 mt-2">
                <div className="flex justify-between font-semibold">
                  <span>{t('totalCost')}:</span>
                  <span className="text-hotel-blue">${total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>{t('checkIn')}</Label>
              <Input
                type="date"
                value={formData.checkInDate}
                onChange={(e) => setFormData({ ...formData, checkInDate: e.target.value })}
                required
              />
            </div>
            <div>
              <Label>{t('checkOut')}</Label>
              <Input
                type="date"
                value={formData.checkOutDate}
                onChange={(e) => setFormData({ ...formData, checkOutDate: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>{t('firstName')}</Label>
              <Input
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="Enter first name"
                required
              />
            </div>
            <div>
              <Label>{t('lastName')}</Label>
              <Input
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="Enter last name"
                required
              />
            </div>
          </div>

          <div>
            <Label>{t('email')}</Label>
            <Input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="Enter email address"
              required
            />
          </div>

          <div>
            <Label>{t('phone')}</Label>
            <Input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="Enter phone number"
              required
            />
          </div>

          <div>
            <Label>{t('specialRequests')}</Label>
            <Textarea
              value={formData.specialRequests}
              onChange={(e) => setFormData({ ...formData, specialRequests: e.target.value })}
              placeholder="Any special requests or preferences..."
              rows={3}
            />
          </div>

          <div className="flex space-x-4 pt-4">
            <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
              {t('cancel')}
            </Button>
            <Button 
              type="submit" 
              className="flex-1 bg-hotel-blue hover:bg-hotel-blue/90"
              disabled={bookingMutation.isPending}
            >
              {bookingMutation.isPending ? t('loading') : t('confirmBooking')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
