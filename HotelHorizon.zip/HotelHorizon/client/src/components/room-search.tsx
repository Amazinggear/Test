import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Search } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { SearchFilters } from "@/types";

interface RoomSearchProps {
  onSearch: (filters: SearchFilters) => void;
}

export function RoomSearch({ onSearch }: RoomSearchProps) {
  const { t } = useLanguage();
  const [filters, setFilters] = useState<SearchFilters>({});

  const handleSearch = () => {
    onSearch(filters);
  };

  return (
    <Card className="bg-white shadow-xl -mt-20 relative z-10 mx-4 md:mx-8">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4 text-hotel-text">{t('findRoom')}</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">{t('checkIn')}</Label>
            <Input
              type="date"
              value={filters.checkIn || ''}
              onChange={(e) => setFilters({ ...filters, checkIn: e.target.value })}
              className="focus:ring-hotel-blue focus:border-hotel-blue"
            />
          </div>
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">{t('checkOut')}</Label>
            <Input
              type="date"
              value={filters.checkOut || ''}
              onChange={(e) => setFilters({ ...filters, checkOut: e.target.value })}
              className="focus:ring-hotel-blue focus:border-hotel-blue"
            />
          </div>
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">{t('roomType')}</Label>
            <Select value={filters.roomType} onValueChange={(value) => setFilters({ ...filters, roomType: value })}>
              <SelectTrigger className="focus:ring-hotel-blue focus:border-hotel-blue">
                <SelectValue placeholder={t('allTypes')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allTypes')}</SelectItem>
                <SelectItem value="standard">{t('standard')}</SelectItem>
                <SelectItem value="deluxe">{t('deluxe')}</SelectItem>
                <SelectItem value="suite">{t('suite')}</SelectItem>
                <SelectItem value="presidential">{t('presidential')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">{t('guests')}</Label>
            <Select value={filters.guests?.toString()} onValueChange={(value) => setFilters({ ...filters, guests: parseInt(value) })}>
              <SelectTrigger className="focus:ring-hotel-blue focus:border-hotel-blue">
                <SelectValue placeholder="1 Guest" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 Guest</SelectItem>
                <SelectItem value="2">2 Guests</SelectItem>
                <SelectItem value="3">3 Guests</SelectItem>
                <SelectItem value="4">4+ Guests</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end">
            <Button onClick={handleSearch} className="w-full bg-hotel-blue hover:bg-hotel-blue/90">
              <Search className="w-4 h-4 mr-2" />
              {t('searchRooms')}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
