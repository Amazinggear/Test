import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Hotel } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { LoginCredentials, AdminUser } from "@/types";

interface AdminLoginProps {
  onLogin: (user: AdminUser, token: string) => void;
}

export function AdminLogin({ onLogin }: AdminLoginProps) {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [credentials, setCredentials] = useState<LoginCredentials>({
    email: '',
    password: ''
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginCredentials) => {
      const response = await apiRequest('POST', '/api/auth/login', data);
      return response.json();
    },
    onSuccess: (data) => {
      localStorage.setItem('adminToken', data.token);
      onLogin(data.user, data.token);
      toast({
        title: t('success'),
        description: "Login successful!",
      });
    },
    onError: () => {
      toast({
        title: t('error'),
        description: "Invalid credentials. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate(credentials);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-hotel-blue to-blue-700 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-hotel-blue rounded-full flex items-center justify-center mx-auto mb-4">
              <Hotel className="text-white text-2xl" />
            </div>
            <h2 className="text-2xl font-bold text-hotel-text">{t('adminLogin')}</h2>
            <p className="text-gray-600 mt-2">Sign in to access hotel management</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>{t('email')}</Label>
              <Input
                type="email"
                value={credentials.email}
                onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
                placeholder="admin@azurepalace.com"
                required
              />
            </div>

            <div>
              <Label>Password</Label>
              <Input
                type="password"
                value={credentials.password}
                onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                placeholder="Enter your password"
                required
              />
            </div>

            <Button 
              type="submit" 
              className="w-full bg-hotel-blue hover:bg-hotel-blue/90"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? t('loading') : t('signIn')}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
