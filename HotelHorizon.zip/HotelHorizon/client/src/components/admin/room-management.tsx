import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Edit, Trash2 } from "lucide-react";
import { Room, InsertRoom } from "@shared/schema";

interface RoomManagementProps {
  token: string;
}

export function RoomManagement({ token }: RoomManagementProps) {
  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [formData, setFormData] = useState<Partial<InsertRoom>>({
    number: '',
    floor: 1,
    type: 'standard',
    status: 'available',
    price: '',
    capacity: 2,
    size: 25,
    description: '',
    amenities: [],
  });

  const { data: rooms, isLoading } = useQuery({
    queryKey: ['/api/admin/rooms'],
    queryFn: async () => {
      const response = await fetch('/api/admin/rooms', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch rooms');
      return response.json();
    }
  });

  const addRoomMutation = useMutation({
    mutationFn: async (data: Partial<InsertRoom>) => {
      const response = await fetch('/api/admin/rooms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Failed to add room');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/rooms'] });
      setIsAddModalOpen(false);
      resetForm();
      toast({ title: "Success", description: "Room added successfully!" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add room", variant: "destructive" });
    }
  });

  const updateRoomMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertRoom> }) => {
      const response = await fetch(`/api/admin/rooms/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Failed to update room');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/rooms'] });
      setEditingRoom(null);
      resetForm();
      toast({ title: "Success", description: "Room updated successfully!" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update room", variant: "destructive" });
    }
  });

  const deleteRoomMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/admin/rooms/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to delete room');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/rooms'] });
      toast({ title: "Success", description: "Room deleted successfully!" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete room", variant: "destructive" });
    }
  });

  const resetForm = () => {
    setFormData({
      number: '',
      floor: 1,
      type: 'standard',
      status: 'available',
      price: '',
      capacity: 2,
      size: 25,
      description: '',
      amenities: [],
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRoom) {
      updateRoomMutation.mutate({ id: editingRoom.id, data: formData });
    } else {
      addRoomMutation.mutate(formData);
    }
  };

  const handleEdit = (room: Room) => {
    setEditingRoom(room);
    setFormData({
      number: room.number,
      floor: room.floor,
      type: room.type,
      status: room.status,
      price: room.price,
      capacity: room.capacity,
      size: room.size || 25,
      description: room.description || '',
      amenities: room.amenities || [],
    });
    setIsAddModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this room?')) {
      deleteRoomMutation.mutate(id);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-hotel-success/10 text-hotel-success';
      case 'occupied': return 'bg-red-100 text-red-800';
      case 'maintenance': return 'bg-hotel-warning/10 text-hotel-warning';
      case 'cleaning': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return <div className="p-6">{t('loading')}</div>;
  }

  const availableRooms = rooms?.filter((r: Room) => r.status === 'available').length || 0;
  const occupiedRooms = rooms?.filter((r: Room) => r.status === 'occupied').length || 0;
  const maintenanceRooms = rooms?.filter((r: Room) => r.status === 'maintenance').length || 0;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-hotel-text mb-2">{t('roomManagement')}</h2>
          <p className="text-gray-600">Manage room inventory and status</p>
        </div>
        <Button
          onClick={() => setIsAddModalOpen(true)}
          className="bg-hotel-blue hover:bg-hotel-blue/90"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add New Room
        </Button>
      </div>

      {/* Room Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-hotel-success rounded-full mr-3"></div>
              <span className="text-sm font-medium text-gray-600">Available</span>
              <span className="ml-auto text-lg font-bold text-hotel-success">{availableRooms}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-3"></div>
              <span className="text-sm font-medium text-gray-600">Occupied</span>
              <span className="ml-auto text-lg font-bold text-red-500">{occupiedRooms}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-hotel-warning rounded-full mr-3"></div>
              <span className="text-sm font-medium text-gray-600">Maintenance</span>
              <span className="ml-auto text-lg font-bold text-hotel-warning">{maintenanceRooms}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Rooms Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Rooms</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-hotel-bg">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Room</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Capacity</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {rooms?.map((room: Room) => (
                  <tr key={room.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-hotel-text">{room.number}</div>
                      <div className="text-sm text-gray-500">Floor {room.floor}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-hotel-text capitalize">{room.type}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Badge className={getStatusColor(room.status)}>
                        {room.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-hotel-text">${room.price}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-hotel-text">{room.capacity} guests</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(room)}
                          className="text-hotel-blue hover:text-blue-700"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(room.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Room Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={(open) => {
        setIsAddModalOpen(open);
        if (!open) {
          setEditingRoom(null);
          resetForm();
        }
      }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingRoom ? 'Edit Room' : 'Add New Room'}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Room Number</Label>
                <Input
                  value={formData.number}
                  onChange={(e) => setFormData({ ...formData, number: e.target.value })}
                  placeholder="e.g., 401"
                  required
                />
              </div>
              <div>
                <Label>Floor</Label>
                <Select value={formData.floor?.toString()} onValueChange={(value) => setFormData({ ...formData, floor: parseInt(value) })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Floor 1</SelectItem>
                    <SelectItem value="2">Floor 2</SelectItem>
                    <SelectItem value="3">Floor 3</SelectItem>
                    <SelectItem value="4">Floor 4</SelectItem>
                    <SelectItem value="5">Floor 5</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Room Type</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value as any })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="deluxe">Deluxe</SelectItem>
                    <SelectItem value="suite">Suite</SelectItem>
                    <SelectItem value="presidential">Presidential</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Price per Night</Label>
                <Input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  placeholder="299"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Capacity (guests)</Label>
                <Input
                  type="number"
                  value={formData.capacity}
                  onChange={(e) => setFormData({ ...formData, capacity: parseInt(e.target.value) })}
                  min="1"
                  max="10"
                  required
                />
              </div>
              <div>
                <Label>Size (sqm)</Label>
                <Input
                  type="number"
                  value={formData.size}
                  onChange={(e) => setFormData({ ...formData, size: parseInt(e.target.value) })}
                  placeholder="25"
                />
              </div>
            </div>

            <div className="flex space-x-4 pt-4">
              <Button type="button" variant="outline" className="flex-1" onClick={() => setIsAddModalOpen(false)}>
                {t('cancel')}
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-hotel-blue hover:bg-hotel-blue/90"
                disabled={addRoomMutation.isPending || updateRoomMutation.isPending}
              >
                {(addRoomMutation.isPending || updateRoomMutation.isPending) ? t('loading') : (editingRoom ? t('update') : t('add'))}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
