import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";
import { useQuery } from "@tanstack/react-query";
import { CalendarCheck, ChartPie, DollarSign, Bed, Users, Calendar, BarChart3, UserCheck } from "lucide-react";
import { AdminUser } from "@/types";
import { RoomManagement } from "./room-management";
import { BookingManagement } from "./booking-management";
import { Reports } from "./reports";

interface AdminDashboardProps {
  user: AdminUser;
  token: string;
  onLogout: () => void;
}

export function AdminDashboard({ user, token, onLogout }: AdminDashboardProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState('dashboard');

  // Set up authorization header for requests
  useEffect(() => {
    // This will be used by the query client for authenticated requests
    window.localStorage.setItem('adminToken', token);
  }, [token]);

  const { data: bookingStats } = useQuery({
    queryKey: ['/api/admin/analytics/booking-stats'],
    queryFn: async () => {
      const response = await fetch('/api/admin/analytics/booking-stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch booking stats');
      return response.json();
    }
  });

  const { data: occupancyData } = useQuery({
    queryKey: ['/api/admin/analytics/occupancy'],
    queryFn: async () => {
      const response = await fetch('/api/admin/analytics/occupancy', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch occupancy');
      return response.json();
    }
  });

  const { data: revenueData } = useQuery({
    queryKey: ['/api/admin/analytics/revenue'],
    queryFn: async () => {
      const response = await fetch('/api/admin/analytics/revenue', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch revenue');
      return response.json();
    }
  });

  const navItems = [
    { id: 'dashboard', label: t('dashboard'), icon: BarChart3 },
    { id: 'rooms', label: t('roomManagement'), icon: Bed },
    { id: 'bookings', label: t('bookingManagement'), icon: CalendarCheck },
    { id: 'reports', label: t('reports'), icon: ChartPie },
    { id: 'guests', label: t('guestManagement'), icon: Users },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'rooms':
        return <RoomManagement token={token} />;
      case 'bookings':
        return <BookingManagement token={token} />;
      case 'reports':
        return <Reports token={token} />;
      case 'guests':
        return <div className="p-6">Guest Management - Coming Soon</div>;
      default:
        return (
          <div>
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-hotel-text mb-2">Dashboard Overview</h2>
              <p className="text-gray-600">Monitor your hotel's performance and key metrics</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Bookings</p>
                      <p className="text-3xl font-bold text-hotel-text">{bookingStats?.total || 0}</p>
                      <p className="text-sm text-hotel-success">Active reservations</p>
                    </div>
                    <div className="w-12 h-12 bg-hotel-blue/10 rounded-lg flex items-center justify-center">
                      <CalendarCheck className="text-hotel-blue text-xl" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Occupancy Rate</p>
                      <p className="text-3xl font-bold text-hotel-text">{occupancyData?.occupancyRate?.toFixed(1) || 0}%</p>
                      <p className="text-sm text-hotel-success">Current rate</p>
                    </div>
                    <div className="w-12 h-12 bg-luxury-gold/10 rounded-lg flex items-center justify-center">
                      <ChartPie className="text-luxury-gold text-xl" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Revenue</p>
                      <p className="text-3xl font-bold text-hotel-text">${(revenueData?.revenue || 0).toLocaleString()}</p>
                      <p className="text-sm text-hotel-success">Total earnings</p>
                    </div>
                    <div className="w-12 h-12 bg-hotel-success/10 rounded-lg flex items-center justify-center">
                      <DollarSign className="text-hotel-success text-xl" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Confirmed</p>
                      <p className="text-3xl font-bold text-hotel-text">{bookingStats?.confirmed || 0}</p>
                      <p className="text-sm text-gray-500">Confirmed bookings</p>
                    </div>
                    <div className="w-12 h-12 bg-hotel-warning/10 rounded-lg flex items-center justify-center">
                      <UserCheck className="text-hotel-warning text-xl" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-hotel-success rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">New booking confirmed</p>
                        <p className="text-xs text-gray-500">Room 101 - John Smith</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-hotel-warning rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Room maintenance scheduled</p>
                        <p className="text-xs text-gray-500">Room 205 - Cleaning in progress</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-hotel-blue rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Check-in completed</p>
                        <p className="text-xs text-gray-500">Suite 301 - Sarah Johnson</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Pending Bookings</span>
                      <span className="text-sm font-medium">{bookingStats?.pending || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Checked In</span>
                      <span className="text-sm font-medium">{bookingStats?.checkedIn || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Checked Out</span>
                      <span className="text-sm font-medium">{bookingStats?.checkedOut || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Cancelled</span>
                      <span className="text-sm font-medium">{bookingStats?.cancelled || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="bg-hotel-bg min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-hotel-blue">Azure Palace Admin</h1>
              <span className="text-sm bg-hotel-success text-white px-2 py-1 rounded">Online</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.name}</span>
              <Button variant="outline" size="sm" onClick={onLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-sm h-screen">
          <nav className="p-4">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-2 text-left rounded-lg transition-colors ${
                      activeTab === item.id
                        ? 'bg-hotel-blue text-white'
                        : 'text-gray-600 hover:bg-hotel-bg hover:text-hotel-blue'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}
