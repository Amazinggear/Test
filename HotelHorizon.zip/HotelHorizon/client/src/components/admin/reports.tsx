import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";
import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Star } from "lucide-react";

interface ReportsProps {
  token: string;
}

export function Reports({ token }: ReportsProps) {
  const { t } = useLanguage();
  const [dateRange, setDateRange] = useState({
    from: '2024-12-01',
    to: '2024-12-31'
  });
  const revenueChartRef = useRef<HTMLCanvasElement>(null);
  const occupancyChartRef = useRef<HTMLCanvasElement>(null);
  const monthlyRevenueChartRef = useRef<HTMLCanvasElement>(null);
  const occupancyRatesChartRef = useRef<HTMLCanvasElement>(null);

  const { data: revenueData } = useQuery({
    queryKey: ['/api/admin/analytics/revenue', dateRange],
    queryFn: async () => {
      const params = new URLSearchParams({
        startDate: dateRange.from,
        endDate: dateRange.to
      });
      const response = await fetch(`/api/admin/analytics/revenue?${params.toString()}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch revenue data');
      return response.json();
    }
  });

  const { data: occupancyData } = useQuery({
    queryKey: ['/api/admin/analytics/occupancy', dateRange],
    queryFn: async () => {
      const params = new URLSearchParams({
        startDate: dateRange.from,
        endDate: dateRange.to
      });
      const response = await fetch(`/api/admin/analytics/occupancy?${params.toString()}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch occupancy data');
      return response.json();
    }
  });

  const { data: roomTypeStats } = useQuery({
    queryKey: ['/api/admin/analytics/room-types'],
    queryFn: async () => {
      const response = await fetch('/api/admin/analytics/room-types', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch room type stats');
      return response.json();
    }
  });

  useEffect(() => {
    // Load Chart.js dynamically
    const loadCharts = async () => {
      if (typeof window !== 'undefined' && !window.Chart) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
        script.onload = () => initializeCharts();
        document.head.appendChild(script);
      } else if (window.Chart) {
        initializeCharts();
      }
    };

    const initializeCharts = () => {
      if (!window.Chart) return;

      // Revenue Trend Chart
      if (revenueChartRef.current) {
        const ctx = revenueChartRef.current.getContext('2d');
        if (ctx) {
          new window.Chart(ctx, {
            type: 'line',
            data: {
              labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
              datasets: [{
                label: 'Revenue ($)',
                data: [32000, 35000, 42000, 38000, 45000, 52000, 58000, 55000, 48000, 51000, 47000, revenueData?.revenue || 62000],
                borderColor: '#2C5AA0',
                backgroundColor: 'rgba(44, 90, 160, 0.1)',
                tension: 0.4,
                fill: true
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false
                }
              },
              scales: {
                y: {
                  beginAtZero: true,
                  ticks: {
                    callback: function(value: any) {
                      return '$' + value.toLocaleString();
                    }
                  }
                }
              }
            }
          });
        }
      }

      // Occupancy Chart
      if (occupancyChartRef.current && roomTypeStats) {
        const ctx = occupancyChartRef.current.getContext('2d');
        if (ctx) {
          new window.Chart(ctx, {
            type: 'doughnut',
            data: {
              labels: roomTypeStats.map((stat: any) => stat.type),
              datasets: [{
                data: roomTypeStats.map((stat: any) => stat.count),
                backgroundColor: ['#2C5AA0', '#D4AF37', '#28A745', '#FFC107']
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  position: 'bottom'
                }
              }
            }
          });
        }
      }

      // Monthly Revenue Chart
      if (monthlyRevenueChartRef.current) {
        const ctx = monthlyRevenueChartRef.current.getContext('2d');
        if (ctx) {
          new window.Chart(ctx, {
            type: 'bar',
            data: {
              labels: ['Oct', 'Nov', 'Dec'],
              datasets: [{
                label: 'Revenue',
                data: [51000, 47000, revenueData?.revenue || 62000],
                backgroundColor: '#2C5AA0'
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false
                }
              },
              scales: {
                y: {
                  beginAtZero: true,
                  ticks: {
                    callback: function(value: any) {
                      return '$' + value.toLocaleString();
                    }
                  }
                }
              }
            }
          });
        }
      }

      // Occupancy Rates Chart
      if (occupancyRatesChartRef.current) {
        const ctx = occupancyRatesChartRef.current.getContext('2d');
        if (ctx) {
          new window.Chart(ctx, {
            type: 'line',
            data: {
              labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
              datasets: [{
                label: 'Occupancy %',
                data: [85, 87, 83, occupancyData?.occupancyRate || 91],
                borderColor: '#D4AF37',
                backgroundColor: 'rgba(212, 175, 55, 0.1)',
                tension: 0.4,
                fill: true
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false
                }
              },
              scales: {
                y: {
                  beginAtZero: true,
                  max: 100,
                  ticks: {
                    callback: function(value: any) {
                      return value + '%';
                    }
                  }
                }
              }
            }
          });
        }
      }
    };

    loadCharts();
  }, [revenueData, occupancyData, roomTypeStats]);

  const handleGenerateReport = () => {
    // This would trigger report generation with the selected date range
    console.log('Generating report for:', dateRange);
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-hotel-text mb-2">{t('reports')} & Analytics</h2>
        <p className="text-gray-600">Comprehensive insights into hotel performance</p>
      </div>

      {/* Date Range Selector */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-1">From Date</Label>
              <Input
                type="date"
                value={dateRange.from}
                onChange={(e) => setDateRange({ ...dateRange, from: e.target.value })}
                className="text-sm"
              />
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-1">To Date</Label>
              <Input
                type="date"
                value={dateRange.to}
                onChange={(e) => setDateRange({ ...dateRange, to: e.target.value })}
                className="text-sm"
              />
            </div>
            <div className="pt-6">
              <Button 
                onClick={handleGenerateReport}
                className="bg-hotel-blue hover:bg-hotel-blue/90"
              >
                Generate Report
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Revenue Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <canvas ref={monthlyRevenueChartRef}></canvas>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Occupancy Rates</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <canvas ref={occupancyRatesChartRef}></canvas>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Top Performing Rooms</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {roomTypeStats?.map((stat: any, index: number) => (
                <div key={stat.type} className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 capitalize">{stat.type}</span>
                  <span className="text-sm font-medium text-hotel-blue">
                    {stat.occupancyRate.toFixed(1)}% occupancy
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Average Daily Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-hotel-blue mb-2">$425</div>
            <div className="text-sm text-hotel-success flex items-center">
              <TrendingUp className="w-4 h-4 mr-1" />
              8.5% vs last month
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Guest Satisfaction</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-luxury-gold mb-2">4.8/5</div>
            <div className="text-sm text-hotel-success flex items-center">
              <Star className="w-4 h-4 mr-1 fill-current" />
              Based on 248 reviews
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <canvas ref={revenueChartRef}></canvas>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Occupancy by Room Type</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <canvas ref={occupancyChartRef}></canvas>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Extend the window interface to include Chart.js
declare global {
  interface Window {
    Chart: any;
  }
}
