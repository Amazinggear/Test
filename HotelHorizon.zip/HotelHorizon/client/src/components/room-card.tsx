import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wifi, Tv, Coffee, Users } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { Room } from "@shared/schema";

interface RoomCardProps {
  room: Room;
  onSelect: (room: Room) => void;
}

export function RoomCard({ room, onSelect }: RoomCardProps) {
  const { t } = useLanguage();

  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case 'wifi':
        return <Wifi className="w-4 h-4" />;
      case 'tv':
        return <Tv className="w-4 h-4" />;
      case 'coffee':
        return <Coffee className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getRoomTypeImage = (type: string) => {
    const imageMap = {
      deluxe: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500',
      suite: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500',
      standard: 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500',
      presidential: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500'
    };
    return imageMap[type as keyof typeof imageMap] || imageMap.deluxe;
  };

  const getRoomTypeName = (type: string) => {
    switch (type) {
      case 'standard':
        return t('standardTwin');
      case 'deluxe':
        return t('deluxeKing');
      case 'suite':
        return t('executiveSuite');
      case 'presidential':
        return t('presidentialSuite');
      default:
        return type;
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow">
      <img
        src={getRoomTypeImage(room.type)}
        alt={getRoomTypeName(room.type)}
        className="w-full h-64 object-cover"
      />
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-semibold text-hotel-text">
              {getRoomTypeName(room.type)}
            </h3>
            <p className="text-gray-600 text-sm">
              {room.size}m² • Room {room.number} • Floor {room.floor}
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-hotel-blue">${room.price}</div>
            <div className="text-sm text-gray-500">{t('perNight')}</div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
          <span className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            {room.capacity} Guests
          </span>
          {room.amenities?.slice(0, 2).map((amenity, index) => (
            <span key={index} className="flex items-center">
              {getAmenityIcon(amenity)}
              <span className="ml-1 capitalize">{amenity}</span>
            </span>
          ))}
        </div>

        {room.status === 'available' && (
          <Badge variant="outline" className="mb-4 text-hotel-success border-hotel-success">
            Available
          </Badge>
        )}
        
        <Button
          onClick={() => onSelect(room)}
          className="w-full bg-hotel-blue hover:bg-hotel-blue/90"
          disabled={room.status !== 'available'}
        >
          {t('selectRoom')}
        </Button>
      </CardContent>
    </Card>
  );
}
