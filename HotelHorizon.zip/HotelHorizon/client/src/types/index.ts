export interface SearchFilters {
  checkIn?: string;
  checkOut?: string;
  roomType?: string;
  guests?: number;
}

export interface BookingFormData {
  roomId: string;
  checkInDate: string;
  checkOutDate: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  specialRequests?: string;
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AnalyticsData {
  occupancyRate: number;
  revenue: number;
  totalBookings: number;
  availableRooms: number;
}
