import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";
import { useQuery } from "@tanstack/react-query";
import { LanguageToggle } from "@/components/language-toggle";
import { RoomSearch } from "@/components/room-search";
import { RoomCard } from "@/components/room-card";
import { BookingModal } from "@/components/booking-modal";
import { Link } from "wouter";
import { SearchFilters } from "@/types";
import { Room } from "@shared/schema";
import { Wifi, Utensils, Dumbbell, Star, MapPin, Phone, Mail, Facebook, Twitter, Instagram } from "lucide-react";

export default function Home() {
  const { t, isRTL } = useLanguage();
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({});
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  const { data: rooms, isLoading } = useQuery({
    queryKey: ['/api/rooms', searchFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchFilters.type && searchFilters.type !== 'all') params.append('type', searchFilters.type);
      if (searchFilters.guests) params.append('capacity', searchFilters.guests.toString());
      if (searchFilters.checkIn) params.append('checkIn', searchFilters.checkIn);
      if (searchFilters.checkOut) params.append('checkOut', searchFilters.checkOut);
      
      const response = await fetch(`/api/rooms?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch rooms');
      return response.json();
    }
  });

  const handleRoomSelect = (room: Room) => {
    setSelectedRoom(room);
    setIsBookingModalOpen(true);
  };

  const handleSearch = (filters: SearchFilters) => {
    setSearchFilters(filters);
  };

  return (
    <div className={`min-h-screen bg-hotel-bg ${isRTL ? 'font-arabic' : 'font-sans'}`}>
      <LanguageToggle />
      
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <h1 className="text-2xl font-bold text-hotel-blue">Azure Palace Hotel</h1>
              <span className="text-luxury-gold text-sm flex items-center">
                <Star className="w-4 h-4 mr-1" />
                5 Star Luxury
              </span>
            </div>
            <nav className="hidden md:flex space-x-6 rtl:space-x-reverse">
              <a href="#home" className="text-hotel-text hover:text-hotel-blue transition-colors">{t('home')}</a>
              <a href="#rooms" className="text-hotel-text hover:text-hotel-blue transition-colors">{t('rooms')}</a>
              <a href="#facilities" className="text-hotel-text hover:text-hotel-blue transition-colors">{t('facilities')}</a>
              <a href="#contact" className="text-hotel-text hover:text-hotel-blue transition-colors">{t('contact')}</a>
            </nav>
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <Button className="bg-hotel-blue hover:bg-hotel-blue/90 text-white">
                {t('bookNow')}
              </Button>
              <Link href="/admin">
                <Button variant="outline" size="sm">
                  {t('admin')}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative h-96 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
          }}
        ></div>
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        <div className="relative max-w-7xl mx-auto px-4 h-full flex items-center">
          <div className="text-white max-w-2xl">
            <h1 className="text-5xl font-bold mb-4">{t('heroTitle')}</h1>
            <p className="text-xl mb-6">{t('heroSubtitle')}</p>
            <Button className="bg-luxury-gold text-hotel-text px-8 py-3 hover:bg-luxury-gold/90 font-semibold">
              {t('exploreRooms')}
            </Button>
          </div>
        </div>
      </section>

      {/* Room Search Widget */}
      <section className="py-8">
        <div className="max-w-6xl mx-auto">
          <RoomSearch onSearch={handleSearch} />
        </div>
      </section>

      {/* Rooms Section */}
      <section id="rooms" className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-hotel-text mb-4">Our Luxurious Rooms</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Each room is meticulously designed to provide the ultimate comfort and elegance for our distinguished guests.
            </p>
          </div>
          
          {isLoading ? (
            <div className="text-center py-8">
              <div className="text-lg text-gray-600">{t('loading')}</div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {rooms?.map((room: Room) => (
                <RoomCard
                  key={room.id}
                  room={room}
                  onSelect={handleRoomSelect}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Facilities Section */}
      <section id="facilities" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-hotel-text mb-4">World-Class Facilities</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Immerse yourself in luxury with our comprehensive range of amenities and services designed for your comfort and enjoyment.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <img 
                src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Spa & Wellness" 
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-semibold text-hotel-text mb-2">Spa & Wellness</h3>
              <p className="text-gray-600">Rejuvenate your body and mind at our award-winning spa with premium treatments and therapies.</p>
            </div>
            
            <div className="text-center">
              <img 
                src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Fine Dining" 
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-semibold text-hotel-text mb-2">Fine Dining</h3>
              <p className="text-gray-600">Experience culinary excellence at our signature restaurants featuring international and local cuisine.</p>
            </div>
            
            <div className="text-center">
              <img 
                src="https://images.unsplash.com/photo-1571902943202-507ec2618e8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Fitness Center" 
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-semibold text-hotel-text mb-2">Fitness Center</h3>
              <p className="text-gray-600">Stay active with our state-of-the-art fitness center equipped with the latest exercise equipment.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-hotel-text text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 text-luxury-gold">Azure Palace Hotel</h3>
              <p className="text-gray-300 mb-4">Experience luxury hospitality at its finest in the heart of the city.</p>
              <div className="flex space-x-4 rtl:space-x-reverse">
                <a href="#" className="text-gray-300 hover:text-luxury-gold transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-300 hover:text-luxury-gold transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-300 hover:text-luxury-gold transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
              </div>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">About Us</a></li>
                <li><a href="#rooms" className="text-gray-300 hover:text-white transition-colors">Rooms & Suites</a></li>
                <li><a href="#facilities" className="text-gray-300 hover:text-white transition-colors">Facilities</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Special Offers</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Concierge</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Room Service</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Business Center</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Event Spaces</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-2 text-gray-300">
                <p className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" />
                  123 Luxury Avenue, City Center
                </p>
                <p className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  +1 (555) 123-4567
                </p>
                <p className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  info@azurepalace.com
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-600 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; 2024 Azure Palace Hotel. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Booking Modal */}
      <BookingModal
        room={selectedRoom}
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        checkIn={searchFilters.checkIn}
        checkOut={searchFilters.checkOut}
      />
    </div>
  );
}
