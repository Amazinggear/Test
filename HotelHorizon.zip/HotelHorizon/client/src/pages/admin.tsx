import { useState, useEffect } from "react";
import { AdminLogin } from "@/components/admin/admin-login";
import { AdminDashboard } from "@/components/admin/admin-dashboard";
import { LanguageToggle } from "@/components/language-toggle";
import { useLanguage } from "@/hooks/use-language";
import { AdminUser } from "@/types";

export default function Admin() {
  const { isRTL } = useLanguage();
  const [user, setUser] = useState<AdminUser | null>(null);
  const [token, setToken] = useState<string>('');

  useEffect(() => {
    // Check for existing token on mount
    const savedToken = localStorage.getItem('adminToken');
    if (savedToken) {
      // TODO: Validate token with backend
      // For now, we'll just check if it exists
      setToken(savedToken);
      // You might want to fetch user info here or validate the token
    }
  }, []);

  const handleLogin = (userData: AdminUser, userToken: string) => {
    setUser(userData);
    setToken(userToken);
  };

  const handleLogout = () => {
    setUser(null);
    setToken('');
    localStorage.removeItem('adminToken');
  };

  return (
    <div className={`min-h-screen ${isRTL ? 'font-arabic' : 'font-sans'}`}>
      <LanguageToggle />
      
      {user && token ? (
        <AdminDashboard 
          user={user} 
          token={token} 
          onLogout={handleLogout} 
        />
      ) : (
        <AdminLogin onLogin={handleLogin} />
      )}
    </div>
  );
}
